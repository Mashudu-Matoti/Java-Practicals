import acsse.ThreadTask;

/**
 * 
 */

/**
 * @author NM Matoti
 * @version P03
 *
 */
public class Main {
	
	public static void main(String[] args) {
		//Instantiating server
	ThreadTask task = new ThreadTask(4321); 
	task.promptServer();
	}
}
