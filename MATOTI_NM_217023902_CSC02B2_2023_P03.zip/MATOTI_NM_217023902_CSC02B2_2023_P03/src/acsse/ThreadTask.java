package acsse;

import java.io.IOException;
import java.net.ServerSocket;

/**
 * 
 */

/**
 * @author NM Matoti 
 *@version P03
 */
public class ThreadTask {
	
	/**Attributes*/
	//private int portNum;
	private Boolean bool = false;
	private ServerSocket serverSocket= null;
	
	/**Ctor
	 * 
	 * @param portNum port we want to use for connection
	 */
	public ThreadTask(int portNum) {
		bool = true;
		 try {
			this.serverSocket = new ServerSocket(portNum);
		} catch (IOException e) {
			System.out.println("Could not start server socket");
		}
	}
	/**
	 * Starts server
	 * implements multi-threading approach so that multiple clients can connect to server
	 */
	public void promptServer() {
		try {
			
			while(bool) {
				HttpServer server = new HttpServer(serverSocket.accept());
				Thread thread = new Thread(server);
				thread.start();
			}
			
		} catch (IOException e) {
			
			e.printStackTrace();
		} 
	}
}
