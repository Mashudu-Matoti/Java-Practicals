package acsse;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.util.StringTokenizer;

/**
 * 
 */

/**
 * @author NM Matoti
 * @version P03
 *
 */
public class HttpServer implements Runnable {
	
	/**Attributes*/
	private Socket socket = null;
	private DataOutputStream writer = null;
	private BufferedReader reader = null;
	
	/**
	 * Constructor
	 * @param socket to establish client connection
	 */
	public HttpServer(Socket socket){
		this.socket = socket;
		
			try {
				this.writer = new DataOutputStream(new BufferedOutputStream(this.socket.getOutputStream()));
				this.reader = new BufferedReader(new InputStreamReader(this.socket.getInputStream()));
			} catch (IOException e) {
				e.printStackTrace();
			}
			
	}
	@Override
	public void run() {
		//reads in request and breaks the string into parts
		String line = read();
		if(line != null) {
			System.out.println(line);
			StringTokenizer str2 = new StringTokenizer(line, " ");
			String req = str2.nextToken();
			System.out.println(req);
			//reads in file name requested and removes first two characters
			String fname = str2.nextToken().substring(1);
			System.out.println(fname);
			//Checks suffix to check if file requested is an image or html doc
			String fpath = null;
			if(fname.contains("jpg")) {
				fpath = "./data/"+fname;
			}
			else {
				fpath = "./data/"+fname+".html";
			}
			System.out.println(fpath);
			
			//Creating our file handler
			File file = new File(fpath);
			System.out.println(file.length());
			//Checks existence of file
			if(file.exists()){
				//try-catch for error code 500. If file is found but cannot be sent
				try {
					//If file exists, it checks whether client requested an html doc or image
					if(req.equals("GET") && fpath.contains("html")) {
						//response
						write("HTTP/1.1 200 OK \r\n");
						write("Connection: close \r\n");
						write("Content-Type: text/html \r\n");
						write("Content-Lengh: " + file.length()+ "\r\n");
						write("\r\n");
					}
					else if(req.equals("GET") && fpath.contains("jpg")) {
						//response
						write("HTTP/1.1 200 OK \r\n");
						write("Connection: close \r\n");
						write("Content-Type: image/jpg \r\n");
						write("Content-Lengh: " + file.length()+ "\r\n");
						write("\r\n");
					}
						//reading in file requested in byte format
						BufferedInputStream bStream = null;
						try {
							bStream = new BufferedInputStream(new FileInputStream(file));
							int size = (int)(file.length());
							byte buffer[]= new byte[size];
							int n=0;
							while((n=bStream.read(buffer))>0){
								System.out.println(n);
								writer.write(buffer,0,n);
							}
							write("\r\n");
							this.writer.flush();

						} catch (IOException e) {
							
							System.out.println("Could not read in requested file");
						}
						finally{
							//Close file input stream
							if(bStream != null) {
								try {
									bStream.close();
								} catch (IOException e) {
									System.out.println("Could not close bStream");
								}
							}
					}
						//Closes streams for socket I/O
						this.writer.close();
						this.reader.close();
			}
			catch(Exception e) {
				System.out.println("Server is not responding appropriatelty");
				error500();
				}
			}
		else {
			//handling favicon request
			if(fname.equals("favicon.ico")) {
				System.out.print("Favicon irrelevant for now.");
			}
			else {
				//If file is not found, respond with error code 400
				System.out.println("file not found");
				error400();
			}
			}
		}
	}
	/**
	 * Reads in request from our server
	 * @return clientReq String that is read in
	 */
	private String read(){
		String clientReq = null;
		try {
			clientReq = reader.readLine();
		} catch (IOException e) {
			System.out.println("Could not read request");
			e.printStackTrace();
		}
		return clientReq;
	}
	/**
	 * Takes in a string that will be output our server
	 * @param response String that will be output to server
	 */
	private void write(String response) {
		try {
			this.writer.writeBytes(response);
		} catch (IOException e) {
			System.out.println("Could not write response");
			e.printStackTrace();
		};
	}
	/**
	 * Error code for file not found/client side issues
	 */
	private void error400() {
		write("HTTP/1.1 200 OK \r\n");
		write("Connection: close \r\n");
		write("Content-Type: text/html \r\n");
		write("Content-Lengh: 200 \r\n");
		write("\r\n");
		write("<html>\r\n<head>\r\n<title>404</title>\r\n</head>\r\n<body>\r\n<h1>404 ERROR</h1>\r\n<p>File requested does not exist. Check spelling</p>\r\n</body>\r\n</html>\r\n");
		try {
			this.writer.flush();
		} catch (IOException e) {
			
		}
	}
	/**
	 * Error code for unexpected server side issues
	 */
	private void error500() {
		write("HTTP/1.1 200 OK \r\n");
		write("Connection: close \r\n");
		write("Content-Type: text/html \r\n");
		write("Content-Lengh: 200 \r\n");
		write("\r\n");
		write("<html>\r\n<head>\r\n<title>500</title>\r\n</head>\r\n<body>\r\n<h1>500 ERROR</h1>\r\n<p>Server having trouble loading page</p>\r\n</body>\r\n</html>\r\n");
		try {
			this.writer.flush();
		} catch (IOException e) {
			
		}
	}
}



